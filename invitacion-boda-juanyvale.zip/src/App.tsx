/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { 
  Heart, 
  Calendar, 
  MapPin, 
  Mail, 
  Gift, 
  Clock, 
  Utensils, 
  Navigation,
  Menu,
  X
} from 'lucide-react';

// --- Variants for Cinematic Reveals ---

const cinematicSlideUp = {
  hidden: { opacity: 0, y: 60, filter: 'blur(10px)', scale: 0.95 },
  visible: { 
    opacity: 1, 
    y: 0, 
    filter: 'blur(0px)', 
    scale: 1,
    transition: { 
      duration: 1.2, 
      ease: [0.16, 1, 0.3, 1] 
    } 
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
      delayChildren: 0.1
    }
  }
};

// --- Components ---

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { scrollY } = useScroll();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    return scrollY.on("change", (latest) => {
      setScrolled(latest > 50);
    });
  }, [scrollY]);

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 px-6 py-4 flex justify-between items-center ${
        scrolled ? 'bg-brand-cream/90 backdrop-blur-md border-b border-brand-sage/10 py-3' : 'bg-transparent'
      }`}
    >
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`hover:opacity-70 transition-opacity ${scrolled ? 'text-brand-sage' : 'text-white drop-shadow-md'}`}
        id="menu-toggle"
      >
        <Menu size={24} />
      </button>
      
      <h1 className={`font-serif italic text-lg tracking-widest uppercase transition-colors duration-500 ${
        scrolled ? 'text-brand-sage' : 'text-white drop-shadow-md'
      }`}>
        Juan & Vale
      </h1>
      
      <div className="w-6" />

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="absolute top-full left-0 w-full bg-brand-cream border-b border-brand-sage/10 p-8 shadow-2xl overflow-hidden flex flex-col items-center gap-6"
          >
            <button onClick={() => setIsOpen(false)} className="absolute top-4 right-6 text-brand-sage/50">
              <X size={20} />
            </button>
            {['Welcome', 'The Day', 'Gallery', 'The Venue', 'RSVP'].map((item, i) => (
              <motion.a 
                key={item}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                href={`#${item.toLowerCase().replace(' ', '')}`} 
                onClick={() => setIsOpen(false)} 
                className="font-serif text-2xl hover:text-brand-gold transition-colors text-brand-sage"
              >
                {item === 'Welcome' ? 'Bienvenida' : item === 'The Day' ? 'El Día' : item === 'The Venue' ? 'El Lugar' : item === 'Gallery' ? 'Galería' : item}
              </motion.a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

const SectionHeader = ({ title, subtitle }: { title: string, subtitle?: string }) => (
  <motion.div 
    variants={cinematicSlideUp}
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true, margin: "-100px" }}
    className="text-center mb-16 space-y-4"
  >
    {subtitle && (
      <p className="text-[10px] tracking-[0.4em] uppercase text-brand-sage font-black opacity-60">
        {subtitle}
      </p>
    )}
    <h2 className="font-serif text-5xl md:text-6xl text-brand-charcoal">{title}</h2>
    <div className="w-12 h-[1px] bg-brand-gold/40 mx-auto mt-6" />
  </motion.div>
);

const Countdown = () => {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, mins: 0, secs: 0 });

  useEffect(() => {
    const targetDate = new Date('2026-08-28T00:00:00').getTime();

    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetDate - now;

      if (distance < 0) {
        clearInterval(timer);
        return;
      }

      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        mins: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        secs: Math.floor((distance % (1000 * 60)) / 1000)
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const items = [
    { label: 'Días', value: timeLeft.days },
    { label: 'Horas', value: timeLeft.hours },
    { label: 'Minutos', value: timeLeft.mins },
    { label: 'Segundos', value: timeLeft.secs }
  ];

  return (
    <motion.div 
      variants={staggerContainer}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      className="flex justify-center items-center gap-4 md:gap-12 py-12"
    >
      {items.map((item, idx) => (
        <motion.div key={item.label} variants={cinematicSlideUp} className="flex items-center gap-4 md:gap-12">
          <div className="flex flex-col items-center">
            <motion.span 
              key={item.value}
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              className="font-serif text-5xl md:text-7xl text-brand-sage tabular-nums"
            >
              {item.value}
            </motion.span>
            <span className="text-[10px] tracking-[0.2em] uppercase font-black text-brand-charcoal/40 mt-3">{item.label}</span>
          </div>
          {idx < items.length - 1 && (
            <motion.div initial={{ height: 0 }} whileInView={{ height: 40 }} transition={{ duration: 1.5 }} className="w-[2px] bg-brand-gold/20" />
          )}
        </motion.div>
      ))}
    </motion.div>
  );
};

const Gallery = () => {
  const images = [
    "input_file_2.png",
    "input_file_3.png",
    "input_file_4.png",
  ];

  return (
    <section id="gallery" className="py-24 px-6 max-w-7xl mx-auto">
      <SectionHeader title="Nuestros Momentos" subtitle="Galería" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {images.map((img, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.2, duration: 1 }}
            viewport={{ once: true }}
            className="aspect-[4/5] overflow-hidden rounded-[2rem] shadow-xl hover:scale-[1.02] transition-transform duration-700"
          >
            <img src={img} alt={`Juan & Vale ${i}`} className="w-full h-full object-cover" />
          </motion.div>
        ))}
      </div>
    </section>
  );
};

const MobileNav = () => (
  <motion.footer 
    initial={{ y: 100 }}
    animate={{ y: 0 }}
    transition={{ delay: 1, duration: 1, ease: [0.16, 1, 0.3, 1] }}
    className="fixed bottom-0 left-0 w-full z-50 bg-brand-cream/95 backdrop-blur-xl border-t border-brand-sage/10 flex justify-around items-center px-4 py-3 pb-safe shadow-[0_-10px_40px_rgba(82,96,78,0.1)] md:hidden pointer-events-auto"
  >
    {[
      { icon: Heart, label: 'Home', active: true },
      { icon: Calendar, label: 'Detalles' },
      { icon: Gift, label: 'Galería' },
      { icon: MapPin, label: 'Ubicación' },
      { icon: Mail, label: 'RSVP' }
    ].map((item) => (
      <button 
        key={item.label}
        className={`flex flex-col items-center justify-center transition-all ${item.active ? 'text-brand-sage' : 'text-stone-400 opacity-60'}`}
      >
        <item.icon size={20} fill={item.active ? "currentColor" : "none"} strokeWidth={item.active ? 1.5 : 1} />
        <span className="text-[9px] tracking-[0.1em] uppercase font-bold mt-1.5">{item.label}</span>
      </button>
    ))}
  </motion.footer>
);

// --- Main App ---

export default function App() {
  const { scrollYProgress } = useScroll();
  const heroScale = useTransform(scrollYProgress, [0, 0.3], [1, 1.1]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.3], [1, 0]);

  return (
    <div className="min-h-screen bg-brand-cream font-sans selection:bg-brand-sage/20 overflow-x-hidden">
      <Navbar />
      
      <main className="pb-24">
        {/* Hero Section */}
        <section id="welcome" className="relative h-screen flex flex-col items-center justify-center text-center px-6 overflow-hidden">
          <motion.div 
            style={{ scale: heroScale, opacity: heroOpacity }}
            className="absolute inset-0 z-0"
          >
            <motion.img 
              initial={{ scale: 1.15, filter: 'blur(20px)' }}
              animate={{ scale: 1, filter: 'blur(0px)' }}
              transition={{ duration: 2, ease: [0.16, 1, 0.3, 1] }}
              src="input_file_6.png" 
              alt="Juan & Vale"
              className="w-full h-full object-cover brightness-90 md:brightness-95"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-brand-cream" />
          </motion.div>

          <div className="relative z-10 space-y-12 max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, letterSpacing: '1.5em', y: 20 }}
              animate={{ opacity: 1, letterSpacing: '0.6em', y: 0 }}
              transition={{ duration: 2, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
            >
              <p className="text-xs uppercase text-white drop-shadow-lg font-black">
                Reserva la Fecha
              </p>
            </motion.div>
            
            <motion.h2 
              initial={{ opacity: 0, y: 60, filter: 'blur(15px)', scale: 0.85 }}
              animate={{ opacity: 1, y: 0, filter: 'blur(0px)', scale: 1 }}
              transition={{ duration: 2.2, delay: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="font-serif text-white text-6xl md:text-[12rem] leading-[0.8] italic drop-shadow-2xl px-4"
            >
              Juan & Vale
            </motion.h2>
            
            <motion.div 
              initial={{ scaleX: 0, opacity: 0 }}
              animate={{ scaleX: 1, opacity: 1 }}
              transition={{ delay: 1.8, duration: 1.5, ease: "circOut" }}
              className="h-[1px] bg-white/50 w-24 mx-auto origin-center" 
            />
            
            <motion.p 
              initial={{ opacity: 0, letterSpacing: '0.4em' }}
              animate={{ opacity: 1, letterSpacing: '0.2em' }}
              transition={{ delay: 2.2, duration: 1.5 }}
              className="font-serif text-2xl md:text-4xl text-white font-light drop-shadow-md"
            >
              28.08.2026
            </motion.p>
          </div>
        </section>

        {/* Countdown Section */}
        <section id="countdown" className="py-40 px-6 max-w-5xl mx-auto text-center">
          <Countdown />
        </section>

        {/* Gallery Section */}
        <Gallery />

        {/* Details Section */}
        <section id="theday" className="py-40 bg-stone-50/80 px-6 relative">
          <div className="absolute top-0 left-0 w-full h-full bg-paper-texture opacity-30 pointer-events-none" />
          <SectionHeader title="La Celebración" subtitle="Los Detalles" />
          
          <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-12 md:gap-16">
            {/* Ceremony */}
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={cinematicSlideUp}
              className="space-y-8 bg-white p-12 rounded-[2.5rem] shadow-2xl shadow-brand-sage/5 border border-black/5 hover:translate-y-[-8px] transition-transform duration-700 text-center md:text-left group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                <Heart size={120} />
              </div>
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-brand-cream text-brand-sage mb-2 rotate-3 group-hover:rotate-0 transition-all duration-700">
                <Heart size={32} />
              </div>
              <h3 className="font-serif text-5xl text-brand-charcoal">Ceremonia</h3>
              <p className="text-xl text-brand-charcoal/60 leading-relaxed font-light italic">
                A las tres de la tarde en la hermosa Hacienda La Victoria.
              </p>
              <div className="space-y-6 pt-8 border-t border-brand-sage/10">
                <div className="flex items-center justify-center md:justify-start gap-5 text-brand-charcoal">
                  <div className="p-3 bg-brand-cream rounded-xl text-brand-gold"><Clock size={20} /></div>
                  <span className="text-sm tracking-[0.2em] font-black opacity-60">15:00 PM</span>
                </div>
                <div className="flex items-center justify-center md:justify-start gap-5 text-brand-charcoal">
                  <div className="p-3 bg-brand-cream rounded-xl text-brand-gold"><MapPin size={20} /></div>
                  <span className="text-sm tracking-[0.2em] font-black opacity-60">Hacienda La Victoria</span>
                </div>
              </div>
            </motion.div>

            {/* Reception */}
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={{
                ...cinematicSlideUp,
                visible: { ...cinematicSlideUp.visible, transition: { ...cinematicSlideUp.visible.transition, delay: 0.3 } }
              }}
              className="space-y-8 bg-white p-12 rounded-[2.5rem] shadow-2xl shadow-brand-sage/5 border border-black/5 hover:translate-y-[-8px] transition-transform duration-700 text-center md:text-left group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                <Utensils size={120} />
              </div>
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-brand-cream text-brand-sage mb-2 -rotate-3 group-hover:rotate-0 transition-all duration-700">
                <Utensils size={32} />
              </div>
              <h3 className="font-serif text-5xl text-brand-charcoal">Recepción</h3>
              <p className="text-xl text-brand-charcoal/60 leading-relaxed font-light italic">
                Seguida de una cena de gala y fiesta para celebrar nuestra unión.
              </p>
              <div className="space-y-6 pt-8 border-t border-brand-sage/10">
                <div className="flex items-center justify-center md:justify-start gap-5 text-brand-charcoal">
                  <div className="p-3 bg-brand-cream rounded-xl text-brand-gold"><Clock size={20} /></div>
                  <span className="text-sm tracking-[0.2em] font-black opacity-60">18:30 PM</span>
                </div>
                <div className="flex items-center justify-center md:justify-start gap-5 text-brand-charcoal">
                  <div className="p-3 bg-brand-cream rounded-xl text-brand-gold"><Utensils size={20} /></div>
                  <span className="text-sm tracking-[0.2em] font-black opacity-60">Via Subachoque</span>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Venue Section */}
        <section id="thevenue" className="py-40 px-6 max-w-7xl mx-auto overflow-hidden">
          <div className="flex flex-col md:flex-row items-center gap-24">
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="w-full md:w-1/2 space-y-12 order-2 md:order-1"
            >
              <div className="space-y-4">
                <h3 className="font-serif text-7xl md:text-8xl leading-[0.9] text-brand-charcoal">Hacienda<br/>La Victoria</h3>
                <div className="w-24 h-1 bg-brand-gold mt-4 rounded-full" />
              </div>
              
              <motion.p variants={cinematicSlideUp} className="text-2xl text-brand-charcoal/60 leading-relaxed font-light italic">
                Un lugar mágico rodeado de naturaleza y elegancia en el corazón de Subachoque. 
                Nuestra celebración tendrá lugar en este rincón de paz y belleza.
              </motion.p>
              <motion.button 
                variants={cinematicSlideUp}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-14 py-7 bg-brand-sage text-white text-xs tracking-[0.3em] font-black rounded-2xl shadow-[0_30px_60px_rgba(82,96,78,0.3)] flex items-center justify-center gap-6 w-full md:w-auto group relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                <Navigation size={20} />
                Cómo Llegar
              </motion.button>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 200, scale: 0.7, rotate: 15 }}
              whileInView={{ opacity: 1, x: 0, scale: 1, rotate: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 2, ease: [0.16, 1, 0.3, 1] }}
              className="w-full md:w-1/2 aspect-[3/4] relative overflow-hidden rounded-[3rem] shadow-[-40px_60px_100px_rgba(0,0,0,0.15)] order-1 md:order-2"
            >
              <img 
                src="input_file_0.png" 
                alt="Hacienda La Victoria"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <motion.div 
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ delay: 1, duration: 1 }}
                className="absolute bottom-12 left-12 bg-white/95 backdrop-blur-3xl px-10 py-5 rounded-[2rem] shadow-2xl border border-brand-sage/5"
              >
                <span className="text-[12px] tracking-[0.4em] uppercase font-black text-brand-gold">Subachoque</span>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* RSVP Section */}
        <section id="rsvp" className="py-60 bg-brand-sage px-6 text-center relative overflow-hidden">
          <motion.div 
            initial={{ scale: 1.5, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 0.1 }}
            transition={{ duration: 3 }}
            style={{ 
              backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.2) 2px, transparent 0)',
              backgroundSize: '100px 100px'
            }}
            className="absolute inset-0"
          />

          <div className="max-w-4xl mx-auto space-y-16 relative z-10 text-brand-cream">
            <motion.h3 
              initial={{ opacity: 0, scale: 0.9, filter: 'blur(20px)' }}
              whileInView={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
              viewport={{ once: true }}
              transition={{ duration: 2, ease: [0.16, 1, 0.3, 1] }}
              className="font-serif text-7xl md:text-[14rem] leading-[0.7] italic"
            >
              ¿Nos<br/><span className="pl-12">Acompañan?</span>
            </motion.h3>
            
            <motion.p 
              variants={cinematicSlideUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="text-2xl md:text-3xl text-brand-cream/60 leading-relaxed font-light max-w-2xl mx-auto italic"
            >
              Estamos emocionados de celebrar este día tan especial con nuestra familia y amigos más cercanos. 
              Por favor confirma tu asistencia antes del 1 de Agosto, 2026.
            </motion.p>
            
            <motion.div 
              variants={cinematicSlideUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              transition={{ delay: 0.8 }}
              className="pt-16"
            >
              <button 
                id="rsvp-btn"
                className="px-24 py-10 bg-brand-cream text-brand-sage text-xs tracking-[0.5em] font-black rounded-full hover:bg-white transition-all shadow-[0_40px_100px_rgba(0,0,0,0.4)] hover:scale-110 active:scale-95 duration-700 overflow-hidden relative group"
              >
                <span className="relative z-10">Confirmar Asistencia</span>
                <div className="absolute inset-0 bg-brand-gold opacity-0 group-hover:opacity-20 transition-opacity" />
              </button>
            </motion.div>
          </div>
        </section>
      </main>

      <MobileNav />
    </div>
  );
}
